# Dbweb Android fork status

This source tree is a Dbweb-branded modification of CloudStream. The upstream project is licensed under GPL-3.0; retain this licence and all upstream copyright notices when distributing modified builds.

## Applied in this source tree
- Android application ID changed to `com.chatpataprani.dbweb`.
- App label and Android play-with label changed to Dbweb.
- Launcher icon assets use the original Dbweb W emblem supplied by the project owner; the artwork must not be redrawn.
- Extensions screen includes a Dbweb website card linking to `https://webdd.freeddns.org`.
- Manual repository-add controls remain available, including the existing add-repository dialog and floating action button.
- Existing installed-extension management and compatible extension runtime are retained.
- Empty extension state directs users toward Dbweb.
- Added a GitHub Actions workflow at `.github/workflows/dbweb-android-debug.yml` to build and upload a debug APK artifact after this complete source tree is pushed to GitHub.

## Design direction
- Preserve CloudStream's navigation, media player, extension runtime, and interaction patterns.
- Apply Dbweb branding through restrained colours, typography, logo usage, and card styling rather than replacing the app's core layout.
- Keep animations lightweight and avoid unnecessary background work, especially for lower-powered Android devices.

## Not yet completed or verified
- The Dbweb website currently acts as a link destination, not a live extension catalogue API/manifest. Catalogue-backed browsing, installation, and updates are not connected.
- Full website-to-app visual matching, About/Settings links, Android TV review, accessibility review, and physical-device performance checks remain.
- No APK has been built or runtime-tested yet. The previous local build could not download Gradle 9.4.1 because this environment could not resolve `services.gradle.org`.
- The GitHub repository `chatpataprani/Claude-extension-` currently contains only earlier branding documentation, not this complete Android source tree. The workflow will not run successfully until the full source tree is pushed to that repository.

Do not describe this source snapshot as a verified APK or a finished release.
